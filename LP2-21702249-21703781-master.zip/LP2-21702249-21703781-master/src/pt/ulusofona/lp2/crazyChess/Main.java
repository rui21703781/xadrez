package pt.ulusofona.lp2.crazyChess;
public class Main {

}
